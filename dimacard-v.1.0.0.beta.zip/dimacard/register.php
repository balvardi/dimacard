<?php
include 'includes/db.php';
include 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name'], ENT_QUOTES, 'UTF-8');
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (!$email) {
        die("ایمیل نامعتبر است!");
    }

    if ($password !== $confirm_password) {
        die("رمز عبور و تأیید رمز عبور مطابقت ندارند!");
    }

    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    try {
        $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
        $stmt->execute([$name, $email, $hashed_password]);
        echo "<script>alert('ثبت‌نام با موفقیت انجام شد!');</script>";
        header("Location: login.php");
        exit();
    } catch (PDOException $e) {
        if ($e->getCode() == 23000) { // Duplicate entry
            die("این ایمیل قبلاً ثبت‌نام شده است!");
        } else {
            die("خطا در ثبت‌نام: " . $e->getMessage());
        }
    }
}
?>

<?php include 'templates/header.php'; ?>

<div class="container mt-5">
    <h1 class="text-center">ثبت‌نام</h1>
    <form action="register.php" method="POST" class="mt-4">
        <div class="mb-3">
            <label for="name" class="form-label">نام</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">ایمیل</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">رمز عبور</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <div class="mb-3">
            <label for="confirm_password" class="form-label">تأیید رمز عبور</label>
            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
        </div>
        <button type="submit" class="btn btn-success w-100">ثبت‌نام</button>
    </form>
</div>

<?php include 'templates/footer.php'; ?>