<?php
function validateInput($data, $rules) {
    foreach ($rules as $field => $rule) {
        if (!preg_match($rule, $data[$field])) {
            return false;
        }
    }
    return true;
}

function generateCSRFToken() {
    session_start();
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}

function verifyCSRFToken($token) {
    session_start();
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function isLoggedIn() {
    session_start();
    return isset($_SESSION['user_id']);
}

function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header("Location: login.php");
        exit();
    }
}
?>