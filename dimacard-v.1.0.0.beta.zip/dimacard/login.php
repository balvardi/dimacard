<?php
session_start();
include 'includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
    $password = $_POST['password'];

    if (!$email) {
        die("ایمیل نامعتبر است!");
    }

    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            echo "<script>alert('ورود موفقیت‌آمیز!');</script>";
            header("Location: index.php");
            exit();
        } else {
            die("ایمیل یا رمز عبور اشتباه است!");
        }
    } catch (PDOException $e) {
        die("خطا در ورود: " . $e->getMessage());
    }
}
?>

<?php include 'templates/header.php'; ?>

<div class="container mt-5">
    <h1 class="text-center">ورود</h1>
    <form action="login.php" method="POST" class="mt-4">
        <div class="mb-3">
            <label for="email" class="form-label">ایمیل</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">رمز عبور</label>
            <input type="password" class="form-control" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary w-100">ورود</button>
    </form>
</div>

<?php include 'templates/footer.php'; ?>