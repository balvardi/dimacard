document.addEventListener('DOMContentLoaded', () => {
    const themeImages = document.querySelectorAll('.theme-preview img');
    themeImages.forEach(img => {
        img.addEventListener('click', () => {
            document.body.style.backgroundImage = `url(${img.src})`;
        });
    });
});