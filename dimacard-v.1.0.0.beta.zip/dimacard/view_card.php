<?php
include 'includes/db.php';

// دریافت unique_id از URL
$unique_id = $_GET['id'] ?? '';

if (!$unique_id) {
    die("لینک نامعتبر است!");
}

// یافتن کارت بر اساس unique_id
$stmt = $pdo->prepare("SELECT * FROM cards WHERE unique_id = ?");
$stmt->execute([$unique_id]);
$card = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$card) {
    die("کارت تبریک یافت نشد!");
}
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>کارت تبریک</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
</head>
<body>
    <div class="container text-center mt-5">
        <h1 id="card-title">کارت تبریک</h1>
        <p id="card-message"><?php echo htmlspecialchars($card['message'], ENT_QUOTES, 'UTF-8'); ?></p>
        <div class="card-animation">
            <div class="balloon"></div>
            <div class="confetti"></div>
        </div>
    </div>

    <script>
        gsap.to(".balloon", { y: -300, duration: 3, ease: "bounce" });
        gsap.to(".confetti", { y: 500, opacity: 0, duration: 2, stagger: 0.1 });
    </script>
</body>
</html>