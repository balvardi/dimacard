<?php
include 'includes/db.php';
include 'includes/functions.php';
redirectIfNotLoggedIn();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $recipient_name = htmlspecialchars($_POST['recipient_name'], ENT_QUOTES, 'UTF-8');
    $recipient_email = filter_var($_POST['recipient_email'], FILTER_VALIDATE_EMAIL);
    $message = htmlspecialchars($_POST['message'], ENT_QUOTES, 'UTF-8');
    $occasion = $_POST['occasion'];

    if (!$recipient_email) {
        die("ایمیل نامعتبر است!");
    }

    $stmt = $pdo->prepare("INSERT INTO cards (user_id, recipient_name, recipient_email, message, occasion) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $recipient_name, $recipient_email, $message, $occasion]);

    echo "<script>alert('کارت تبریک با موفقیت ارسال شد!');</script>";
    header("Location: index.php");
    exit();
}
?>

<?php include 'templates/header.php'; ?>

<div class="container mt-5">
    <h1 class="text-center">ایجاد کارت تبریک</h1>
    <form action="create_card.php" method="POST" class="mt-4">
        <div class="mb-3">
            <label for="recipient_name" class="form-label">نام گیرنده</label>
            <input type="text" class="form-control" id="recipient_name" name="recipient_name" required>
        </div>
        <div class="mb-3">
            <label for="recipient_email" class="form-label">ایمیل گیرنده</label>
            <input type="email" class="form-control" id="recipient_email" name="recipient_email" required>
        </div>
        <div class="mb-3">
            <label for="message" class="form-label">پیام</label>
            <textarea class="form-control" id="message" name="message" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="occasion" class="form-label">مناسبت</label>
            <select class="form-select" id="occasion" name="occasion" required>
                <option value="birthday">تولد</option>
                <option value="wedding">ازدواج</option>
                <option value="new_year">نوروز</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary w-100">ارسال کارت</button>
    </form>
</div>

<?php include 'templates/footer.php'; ?>