<?php include 'includes/db.php'; ?>
<?php include 'templates/header.php'; ?>

<div class="container mt-5">
    <h1 class="text-center">صفحه اصلی</h1>
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <a href="login.php" class="btn btn-primary w-100 mb-2">ورود</a>
            <a href="register.php" class="btn btn-success w-100">ثبت‌نام</a>
        </div>
    </div>
</div>

<?php include 'templates/footer.php'; ?>