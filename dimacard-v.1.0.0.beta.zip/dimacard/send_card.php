<?php
include 'includes/db.php';
include 'includes/functions.php';
redirectIfNotLoggedIn();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // اعتبارسنجی داده‌ها
    $user_id = $_SESSION['user_id'];
    $recipient_name = htmlspecialchars($_POST['recipient_name'], ENT_QUOTES, 'UTF-8');
    $recipient_email = filter_var($_POST['recipient_email'], FILTER_VALIDATE_EMAIL);
    $message = htmlspecialchars($_POST['message'], ENT_QUOTES, 'UTF-8');
    $occasion = $_POST['occasion'];

    if (!$recipient_email) {
        die("ایمیل نامعتبر است!");
    }

    // تولید unique_id برای کارت
    $unique_id = bin2hex(random_bytes(8)); // یک رشته 16 کاراکتری تصادفی

    // ذخیره اطلاعات کارت در پایگاه داده
    $stmt = $pdo->prepare("INSERT INTO cards (user_id, recipient_name, recipient_email, message, occasion, unique_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $recipient_name, $recipient_email, $message, $occasion, $unique_id]);

    // ارسال ایمیل با استفاده از PHPMailer
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    require 'vendor/autoload.php';

    $mail = new PHPMailer(true);
    try {
        // تنظیمات SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.dimacard.ir'; // سرور SMTP خود را وارد کنید
        $mail->SMTPAuth = true;
        $mail->Username = 'send@dimacard.ir'; // ایمیل خود را وارد کنید
        $mail->Password = 'CmbEWWcryTdQD2w3vpxk'; // رمز عبور خود را وارد کنید
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // تنظیمات ایمیل
        $mail->setFrom('send@dimacard.ir', 'کارت تبریک دیما'); // ایمیل فرستنده
        $mail->addAddress($recipient_email, $recipient_name); // ایمیل گیرنده
        $mail->isHTML(true);
        $mail->Subject = 'کارت تبریک برای شما!';
        $mail->Body    = "
            <h1>کارت تبریک</h1>
            <p>{$message}</p>
            <a href='https://dimacard.ir/view_card.php?id={$unique_id}'>مشاهده کارت</a>
        ";

        // ارسال ایمیل
        $mail->send();
        echo "<script>alert('کارت تبریک با موفقیت ارسال شد!');</script>";
        header("Location: index.php");
        exit();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>